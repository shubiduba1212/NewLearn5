---
name: Custom issue template
about: 자유 템플릿
title: "[FEATURE]ReadMe 파일내 팀명 기재 오류 수정"
labels: "⚙chore"
assignees: mynameisjsoook

---

##  주제/목적이 무엇인가요?
ex) ReadMe 파일에 팀명이 잘못 기재되어 있어서 수정했습니다.


## 💻 체크리스트 내용
- [ ] TODO
- [ ] TODO
- [ ] TODO

## 📚 참고할만한 자료(선택)
