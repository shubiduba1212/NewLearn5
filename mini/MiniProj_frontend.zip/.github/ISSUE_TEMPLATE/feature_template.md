---
name: Feature request
about: 기능 개발 To Do List
title: "[FEATURE][MAIN][SLIDE]메인페이지내 슬라이드 기능 작업"
labels: "\U0001F4ABfeature"
assignees: mynameisjsoook

---

## ⚙ 작업할 기능을 설명해주세요.
ex) 회원가입 페이지에 유효성 검사 기능

## 📌 작업 내용
- [ ] TODO
- [ ] TODO
- [ ] TODO

## 📚 참고할만한 자료(선택)
